BASHPATH -xv

cd /home/mischa/THELI/theli/gui/scripts/

. progs.ini

./create_stdcat_fromLOCAL.sh /data/CCD/MAY2010/ IC4603_ALL OFCD 16:25:40 -24:30:00 2.33333 19 /home/mischa/USNO-A2/

