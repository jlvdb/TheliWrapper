def wrapped_call(script, arglist=None, parallel=False):
    cmdchain = [WRAPPER, stack()[1][3]]
    if parallel:
        scriptstr = os.path.join(".", "parallel_manager.sh")
        scriptstr = scriptstr + " " + script
    else:
        scriptstr = os.path.join(".", script)
    cmdchain.append(scriptstr)
    if arglist is not None:
        cmdchain.extend(arglist)
    subprocess.call(cmdchain)


class theli_scripts(object):
    """wrapper for the basic THELI GUI scripts"""

    @staticmethod
    def adjust_gain(maindir, sciencedir, tag):
        wrapped_call(
            "adjust_gain.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def aplastrom_scamp(args):
        raise NotImplementedError()

    @staticmethod
    def check_files_para(maindir, imdir, tag, minmode, maxmode):
        wrapped_call(
            "check_files_para.sh",
            [maindir, imdir, tag, int(float(minmode)), int(float(maxmode))],
            parallel=True)

    @staticmethod
    def clean_files(maindir, fileprefix, filesuffix):
        wrapped_call(
            "clean_files.sh",
            [maindir, fileprefix, filesuffix],
            parallel=False)

    @staticmethod
    def color_combine(wdir, broadbandim, narrowbandim, broadbandwidth,
                      narrowbandwidth, weight):
        wrapped_call(
            "clean_files.sh",
            [wdir, broadbandim, narrowbandim, broadbandwidth, narrowbandwidth,
             weight],
            parallel=False)

    @staticmethod
    def color_correction_photcat(wdir, imdir, imblue, imgreen, imred, server):
        wrapped_call(
            "color_correction_photcat.sh",
            [wdir, imdir, imblue, imgreen, imred, server],
            parallel=False)

    @staticmethod
    def color_getseeing(wdir, imlist):
        wrapped_call(
            "color_getseeing.sh",
            [wdir, imlist],
            parallel=False)

    @staticmethod
    def combine_color_images_para(args):
        raise NotImplementedError()

    @staticmethod
    def copy_zeroheader(maindir, sciencedir, tag):
        wrapped_call(
            "copy_zeroheader.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def correct_crval_para(maindir, sciencedir, tag, crval):
        wrapped_call(
            "correct_crval_para.sh",
            [maindir, sciencedir, tag, crval],
            parallel=True)

    @staticmethod
    def correct_xtalk(maindir, sciencedir):
        wrapped_call(
            "correct_xtalk.sh",
            [maindir, sciencedir],
            parallel=False)

    @staticmethod
    def create_abs_photo_info(maindir, standarddir, sciencedir, tag):
        wrapped_call(
            "create_abs_photo_info.sh",
            [maindir, standarddir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def create_absphotom_coadd(maindir, sciencedir):
        wrapped_call(
            "create_absphotom_coadd.sh",
            [maindir, sciencedir],
            parallel=False)

    @staticmethod
    def create_astromcats_para(maindir, sciencedir, tag):
        wrapped_call(
            "create_astromcats_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_astromcats_phot_para(maindir, sciencedir, tag):
        wrapped_call(
            "create_astromcats_phot_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_astrometrynet(maindir, sciencedir, tag):
        wrapped_call(
            "create_astrometrynet.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_astrometrynet_photom(maindir, sciencedir, tag):
        wrapped_call(
            "create_astrometrynet_photom.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_astrorefcat_fromIMAGE(impath, dtmin, minarea, catpath):
        wrapped_call(
            "create_astrorefcat_fromIMAGE.sh",
            [impath, str(float(dtmin)), str(float(minarea)), catpath],
            parallel=False)

    @staticmethod
    def create_astrorefcat_fromWEB(maindir, sciencedir, tag, refcat="SDSS-DR9",
                                   server="vizier.u-strasbg.fr"):
        know_refcats = ("SDSS-DR9", "ISGL", "PPMXL", "USNO-B1", "2MASS",
                        "URATI", "SPM4", "UCAC4", "GSC-2.3", "TYC", "ALLSKY")
        if refcat not in know_refcats:
            raise ValueError(
                "unrecognized reference cataloge identifier:", refcat)
        webserver = "vizier.u-strasbg.fr" if refcat == "SDSS-DR9" else server
        wrapped_call(
            "create_astrorefcat_fromWEB.sh",
            [maindir, sciencedir, tag, "%s %s" % (refcat, webserver)],
            parallel=False)

    @staticmethod
    def create_background_masks_para(maindir, sciencedir, skydir="noskydir"):
        wrapped_call(
            "create_background_masks_para.shcp1",
            [maindir, sciencedir, skydir],
            parallel=True)

    @staticmethod
    def create_chisquare_image(args):
        raise NotImplementedError()

    @staticmethod
    def create_cosmicclean(wdir):
        wrapped_call(
            "create_cosmicclean.sh",
            [wdir],
            parallel=False)

    @staticmethod
    def create_debloomedimages_para(maindir, sciencedir, tag, threshold):
        wrapped_call(
            "create_debloomedimages_para.sh",
            [maindir, sciencedir, tag, str(float(threshold))],
            parallel=True)

    @staticmethod
    def create_flat_ratio(maindir, flatdir):
        wrapped_call(
            "create_flat_ratio.sh",
            [maindir, flatdir],
            parallel=False)

    @staticmethod
    def create_global_weights_para(maindir, flatnormdir, sciencedir):
        wrapped_call(
            "create_global_weights_para.sh",
            [maindir, flatnormdir, sciencedir],
            parallel=True)

    @staticmethod
    def create_headerastrom(maindir, sciencedir, tag):
        wrapped_call(
            "create_headerastrom.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def create_illumfringe_para(maindir, sciencedir):
        wrapped_call(
            "create_illumfringe_para.sh",
            [maindir, sciencedir],
            parallel=True)

    @staticmethod
    def createlinks(wdir, scratchdir, chiptoscratch=1):
        wrapped_call(
            "createlinks.sh",
            [wdir, scratchdir, str(int(chiptoscratch))],
            parallel=False)

    @staticmethod
    def create_norm_para(maindir, flatdir):
        wrapped_call(
            "create_norm_para.sh",
            [maindir, flatdir],
            parallel=True)

    @staticmethod
    def create_photillcorr_corrcat_para(maindir, sciencedir, tag):
        wrapped_call(
            "create_photillcorr_corrcat_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_photillcorr_getZP(maindir, sciencedir, tag):
        wrapped_call(
            "create_photillcorr_getZP.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def create_photorefcat_fromWEB(maindir, sciencedir, tag,
                                   server="vizier.u-strasbg.fr"):
        wrapped_call(
            "create_photorefcat_fromWEB.sh",
            [maindir, sciencedir, tag, server],
            parallel=False)

    @staticmethod
    def create_scamp(maindir, sciencedir, tag, photometry_mode=False):
        scampmode = "photom" if photometry_mode else ""
        wrapped_call(
            "create_scamp.sh",
            [maindir, sciencedir, tag, scampmode],
            parallel=False)

    @staticmethod
    def create_scampcats(maindir, sciencedir, tag):
        # needed for multicolorchips
        wrapped_call(
            "create_scampcats.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def create_skysubconst_clean(maindir, sciencedir):
        wrapped_call(
            "create_skysubconst_clean.sh",
            [maindir, sciencedir],
            parallel=False)

    @staticmethod
    def create_skysubconst_para(maindir, sciencedir, tag):
        wrapped_call(
            "create_skysubconst_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_skysub_para(maindir, sciencedir, tag):
        # $4 and $5 in the script are dubious
        wrapped_call(
            "create_skysub_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_smoothedge_para(maindir, sciencedir, tag):
        wrapped_call(
            "create_smoothedge_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_stats_table(maindir, sciencedir, tag, headerdir="headers"):
        wrapped_call(
            "create_stats_table.sh",
            [maindir, sciencedir, tag, headerdir],
            parallel=False)

    @staticmethod
    def create_stdphotom_prepare(maindir, sciencedir, tag):
        wrapped_call(
            "create_stdphotom_prepare.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_tiff(maindir, sciencedir, tag):
        wrapped_call(
            "create_tiff",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def create_weights_para(maindir, sciencedir, tag):
        # need to rerun global create_global_weights_para before
        wrapped_call(
            "create_weights_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def create_xcorrastrom(maindir, sciencedir, tag):
        wrapped_call(
            "create_xcorrastrom.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def create_zeroorderastrom(maindir, sciencedir, tag, use_int=True):
        precision = "int" if use_int else "float"
        wrapped_call(
            "create_zeroorderastrom.sh",
            [maindir, sciencedir, tag, precision],
            parallel=False)

    @staticmethod
    def distribute_sets(maindir, sciencedir, tag, minoverlap):
        wrapped_call(
            "distribute_sets.sh",
            [maindir, sciencedir, tag, str(float(minoverlap))],
            parallel=False)

    @staticmethod
    def get_coadd_zp(impath, refcat, obsfilt, maxphoterr, satlevel, magtype,
                     aperturelist, webadress):
        if refcat not in ("SDSS", "2MASS"):
            raise ValueError("refcat must be either 'SDSS' or '2MASS'")
        wrapped_call(
            "get_coadd_zp.sh",
            [impath, refcat, obsfilt, str(float(maxphoterr)),
             str(int(satlevel)), magtype, aperturelist, webadress],
            parallel=False)

    @staticmethod
    def get_constsky_helper(imdir, tag, instrument, ra1, ra2, dec1, dec2):
        wrapped_call(
            "get_constsky_helper.sh",
            [imdir, tag, instrument, str(float(ra1)), str(float(ra2)),
             str(float(dec1)), str(float(dec2))],
            parallel=False)

    @staticmethod
    def get_ditherradius(scriptdir, imdir, tag):
        wrapped_call(
            "get_ditherradius.sh",
            [scriptdir, imdir, tag],
            parallel=False)

    @staticmethod
    def getmaxoverlap(additionalcrop):
        wrapped_call(
            "getmaxoverlap.sh",
            [str(float(additionalcrop))],
            parallel=False)

    @staticmethod
    def get_nthreads(nchips, ncpu, chip):
        wrapped_call(
            "get_nthreads.sh",
            [str(int(nchips)), str(int(ncpu)), str(int(chip))],
            parallel=True)

    @staticmethod
    def get_refcat_geometry(maindir, sciencedir, tag):
        wrapped_call(
            "get_refcat_geometry.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def get_refcat_radius(scriptdir, imdir, tag):
        wrapped_call(
            "get_refcat_radius.sh",
            [scriptdir, imdir, tag],
            parallel=False)

    @staticmethod
    def get_refcat_radius_2(scriptdir, aheadfilepath):
        wrapped_call(
            "get_refcat_radius_2.sh",
            [scriptdir, aheadfilepath],
            parallel=False)

    @staticmethod
    def get_variables(scriptdir, resampleimdir, spatialtolarcs, magzp, maxmag,
                      aperturesizepix, ravardeg, decvardeg):
        wrapped_call(
            "get_variables.sh",
            [scriptdir, resampleimdir, str(float(spatialtolarcs)),
             str(float(magzp)), str(float(maxmag)), str(int(aperturesizepix)),
             str(float(ravardeg)), str(float(decvardeg))],
            parallel=False)

    @staticmethod
    def gpc1_para_start(gpc1rawimdir):
        wrapped_call(
            "gpc1_para_start.sh",
            [gpc1rawimdir],
            parallel=False)

    @staticmethod
    def id_bright_objects(maindir, sciencedir, tag):
        wrapped_call(
            "id_bright_objects.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def imalyzer(cat, imname, pixscale, xmax, ymax, colorrange, units,
                 scalemin, scalemax, scaling, nstars, dosmoothing=False,
                 usecontour=True):
        if units not in ("arcsec", "pixel", "minFWHM"):
            raise ValueError("unrecognized unit:", units)
        if scaling not in ("fullrange", "max", "absolute"):
            raise ValueError("unrecognized scaling parameter:", scaling)
        smoothing = "smoothed" if dosmoothing else "unsmoothed"
        contour = "yes" if usecontour else "no"
        wrapped_call(
            "imalyzer.py",
            [cat, imname, str(float(pixscale)), str(float(xmax)),
             str(float(ymax)), str(float(colorrange)), units,
             str(float(scalemin)), str(float(scalemax)), scaling, nstars,
             smoothing, contour],
            parallel=False)

    @staticmethod
    def imalyzer_analysis_para(maindir, inst):
        wrapped_call(
            "imalyzer_analysis_para.sh",
            [maindir, inst],
            parallel=True)

    @staticmethod
    def imalyzer_plot_para(maindir, inst, title, colorrange, units, scalemin,
                           scalemax, dosmoothing=False, usecontour=True,
                           showgrid=True, fitpsf=False):
        if units not in ("arcsec", "pixel", "minFWHM"):
            raise ValueError("unrecognized unit:", units)
        smoothing = "smoothed" if dosmoothing else "unsmoothed"
        contour = "yes" if usecontour else "no"
        grid = "grid" if showgrid else "nogrid"
        psf = "polynomial" if fitpsf else "data"
        wrapped_call(
            "imalyzer_analysis_para.sh",
            [maindir, inst, title, str(float(colorrange)), units,
             str(float(scalemin)), str(float(scalemax)), smoothing, contour,
             grid, psf],
            parallel=True)

    @staticmethod
    def make_album(instrument, maindir, sciencedir, tag):
        wrapped_call(
            "make_album_%s.sh" % instrument,
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def makemovie_step1(scriptdir, coadddir, usemask=True):
        mask = "mask" if usemask else "nomask"
        wrapped_call(
            "makemovie_step1.sh",
            [scriptdir, coadddir, mask],
            parallel=True)

    @staticmethod
    def makemovie_step2(scriptdir, coadddir):
        wrapped_call(
            "makemovie_step2.sh",
            [scriptdir, coadddir],
            parallel=True)

    @staticmethod
    def makemovie_step3(args):
        """most parameters unclear"""
        raise NotImplementedError()

    @staticmethod
    def make_scampcat(outfile, *args):
        args = args.append(outfile)
        wrapped_call(
            "make_scampcat.py",
            args,
            parallel=False)

    @staticmethod
    def make_slideshow(psfplotdir, slideshowname):
        wrapped_call(
            "make_slideshow.sh",
            [psfplotdir, slideshowname],
            parallel=False)

    @staticmethod
    def makestatplots(maindir, sciencedir, plottype):
        abspathscience = os.path.join(maindir, sciencedir)
        if int(plottype) not in [range(1, 5)]:
            raise ValueError("plot type must be in range [1, 4]")
        wrapped_call(
            "make_slideshow.sh",
            [abspathscience, str(int(plottype))],
            parallel=False)

    @staticmethod
    def merge_sequence(maindir, sciencedir, tag, ngroups):
        wrapped_call(
            "merge_sequence.sh",
            [maindir, sciencedir, tag, str(int(ngroups))],
            parallel=False)

    @staticmethod
    def merge_sex_ksb(maindir, sciencedir, tag):
        wrapped_call(
            "merge_sex_ksb.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def metacharreplace(string):
        wrapped_call(
            "metacharreplace.py",
            parallel=False)

    @staticmethod
    def nmpfit():
        wrapped_call(
            "nmpfit.py",
            parallel=False)

    @staticmethod
    def parakill(pid):
        wrapped_call(
            "parakill.sh",
            [pid],
            parallel=False)

    @staticmethod
    def parallel_manager(*args):
        wrapped_call(
            "parallel_manager.sh",
            args,
            parallel=False)

    @staticmethod
    def perform_coadd_swarp(maindir, sciencedir):
        wrapped_call(
            "perform_coadd_swarp.sh",
            [maindir, sciencedir],
            parallel=False)

    @staticmethod
    def pmon_astrom_showplots(impath):
        wrapped_call(
            "pmon_astrom_showplots.sh",
            [impath],
            parallel=False)

    @staticmethod
    def pmon_astrom_stats(sciencepath):
        wrapped_call(
            "pmon_astrom_stats.sh",
            [sciencepath],
            parallel=False)

    @staticmethod
    def pmon_ds9(fitsfile):
        wrapped_call(
            "pmon_ds9.sh",
            [fitsfile],
            parallel=False)

    @staticmethod
    def pmon_ds9_show_RGB(fitsfile):
        wrapped_call(
            "pmon_ds9_show_RGB.sh",
            [fitsfile],
            parallel=False)

    @staticmethod
    def pmon_ds9_withcat(fitsfile):
        wrapped_call(
            "pmon_ds9_withcat.sh",
            [fitsfile],
            parallel=False)

    @staticmethod
    def pmon_get_corrected_photcat_calibr_NOMAD_blue(imfile):
        wrapped_call(
            "pmon_get_corrected_photcat_calibr_NOMAD_blue.sh",
            [imfile],
            parallel=False)

    @staticmethod
    def pmon_get_corrected_photcat_calibr_NOMAD_red(imfile):
        wrapped_call(
            "pmon_get_corrected_photcat_calibr_NOMAD_red.sh",
            [imfile],
            parallel=False)

    @staticmethod
    def pmon_getflxscale(sciencedir):
        wrapped_call(
            "pmon_getflxscale.sh",
            [sciencedir],
            parallel=False)

    @staticmethod
    def pmon_getpid(processname):
        wrapped_call(
            "pmon_getpid.sh",
            [processname],
            parallel=False)

    @staticmethod
    def pmon_protocol_theli2(arg):
        wrapped_call(
            "pmon_protocol_theli2.sh",
            [arg],
            parallel=False)

    @staticmethod
    def pmon_putsound(*args):
        raise NotImplementedError()

    @staticmethod
    def pmon_service(abspathscience):
        wrapped_call(
            "pmon_service.sh",
            [abspathscience],
            parallel=False)

    @staticmethod
    def pmon_skycat(fitsfile):
        wrapped_call(
            "pmon_skycat.sh",
            [fitsfile],
            parallel=False)

    @staticmethod
    def pmon_skycat_withcat(fitsfile):
        wrapped_call(
            "pmon_skycat_withcat.sh",
            [fitsfile],
            parallel=False)

    @staticmethod
    def preaniso(catfile, step):
        wrapped_call(
            "preaniso.py",
            [catfile, step],
            parallel=False)

    @staticmethod
    def prepare_coadd_swarp(maindir, sciencedir, tag):
        wrapped_call(
            "prepare_coadd_swarp.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def process_adjustgain_para(maindir, sciencedir):
        wrapped_call(
            "process_adjustgain_para.sh",
            [maindir, sciencedir],
            parallel=True)

    @staticmethod
    def process_background_assistant_para(maindir, sciencedir, maskdir):
        wrapped_call(
            "process_background_assistant_para.sh",
            [maindir, sciencedir, maskdir],
            parallel=True)

    @staticmethod
    def process_background_assistant_para_cp(maindir, sciencedir, tag):
        wrapped_call(
            "process_background_assistant_para.shcp1",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def process_background_para(maindir, sciencedir, skydir="noskydir"):
        wrapped_call(
            "process_background_para.sh",
            [maindir, sciencedir, skydir],
            parallel=True)

    @staticmethod
    def process_bias_para(maindir, biasdir):
        wrapped_call(
            "process_bias_para.sh",
            [maindir, biasdir],
            parallel=True)

    @staticmethod
    def process_collapsecorr_para(maindir, sciencedir, tag):
        # need to revert before rerun
        wrapped_call(
            "process_collapsecorr_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def process_dark_para(maindir, darkdir):
        wrapped_call(
            "process_dark_para.sh",
            [maindir, darkdir],
            parallel=True)

    @staticmethod
    def process_flat_para(maindir, biasdir, flatdir):
        wrapped_call(
            "process_flat_para.sh",
            [maindir, biasdir, flatdir],
            parallel=True)

    @staticmethod
    def process_science_chopnod_para(maindir, sciencedir, tag, pattern="0110",
                                     invert=False):
        invert = 1 if bool(invert) else 0
        if pattern not in ("0110", "1001", "0101", "1010"):
            raise ValueError("invalid chop-nod pattern:", pattern)
        wrapped_call(
            "process_science_chopnod_para.sh",
            [maindir, sciencedir, tag, pattern, invert],
            parallel=True)

    @staticmethod
    def process_science_fringe_para(maindir, sciencedir):
        wrapped_call(
            "process_science_fringe_para.sh",
            [maindir, sciencedir],
            parallel=True)

    @staticmethod
    def process_science_para(maindir, biasdarkdir, flatdir, sciencedir):
        wrapped_call(
            "process_science_para.sh",
            [maindir, biasdarkdir, flatdir, sciencedir],
            parallel=True)

    @staticmethod
    def process_split(instrument, maindir, imdir):
        wrapped_call(
            "process_split_%s.sh" % instrument,
            [maindir, imdir],
            parallel=False)

    @staticmethod
    def pythonimstats(filepath, pixscale):
        wrapped_call(
            "pythonimstats.py",
            [filepath, pixscale],
            parallel=False)

    @staticmethod
    def pythonimanalysis(catfile, imfile, order, pixscale, xmax, ymax,
                         colorrange, units, method, scalemin, scalemax,
                         scaling):
        if units not in ("arcsec", "pixel", "minFWHM"):
            raise ValueError("unrecognized unit:", units)
        if scaling not in ("fullrange", "max", "absolute"):
            raise ValueError("unrecognized scaling parameter:", scaling)
        if method not in ("Polynomial", "Spline"):
            raise ValueError("unrecognized method:", method)
        wrapped_call(
            "pythonimanalysis.py",
            [catfile, imfile, order, str(float(pixscale)), str(float(xmax)),
             str(float(ymax)), str(float(colorrange)), units, method,
             str(float(scalemin)), str(float(scalemax)), scaling],
            parallel=False)

    @staticmethod
    def rename_tofitskey(folder, fitskey):
        wrapped_call(
            "rename_tofitskey.sh",
            [folder, fitskey],
            parallel=False)

    @staticmethod
    def resample_coadd_swarp_para(maindir, sciencedir, tag):
        wrapped_call(
            "resample_coadd_swarp_para.sh",
            [maindir, sciencedir, tag],
            parallel=True)

    @staticmethod
    def resample_filtercosmics(maindir, sciencedir):
        wrapped_call(
            "resample_filtercosmics.sh",
            [maindir, sciencedir],
            parallel=False)

    @staticmethod
    def resolvelinks(targetdir, prefix="", pattern=""):
        wrapped_call(
            "resample_filtercosmics.sh",
            [targetdir, prefix, pattern],
            parallel=False)

    @staticmethod
    def restore_header(maindir, sciencedir, tag):
        wrapped_call(
            "restore_header.sh",
            [maindir, sciencedir, tag],
            parallel=False)

    @staticmethod
    def scampcat(filelist):
        wrapped_call(
            "scampcat.sh",
            filelist,
            parallel=False)

    # ####### some are still missing here

    @staticmethod
    def spread_squence(maindir, sciencedir, tag, ngroups, grouplen):
        wrapped_call(
            "spread_sequence.sh",
            [maindir, sciencedir, tag, str(int(ngroups)), str(int(grouplen))],
            parallel=False)

    @staticmethod
    def subtract_flat_flatoff_para(maindir, flatdir, flatoffdir):
        wrapped_call(
            "subtract_flat_flatoff_para.sh",
            [maindir, flatdir, flatoffdir],
            parallel=True)

    @staticmethod
    def transform_ds9_reg(maindir, sciencedir):
        # need to rerun global create_global_weights_para before
        wrapped_call(
            "transform_ds9_reg.sh",
            [maindir, sciencedir],
            parallel=False)

    @staticmethod
    def update_coadd_header(maindir, sciencedir, tag):
        # theli GUI places here for tag OFCB, even though OFCB.sub is expected
        wrapped_call(
            "update_coadd_header.sh"
            [maindir, sciencedir, tag],
            parallel=False)
