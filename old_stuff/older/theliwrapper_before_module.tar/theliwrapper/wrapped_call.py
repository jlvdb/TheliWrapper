import subprocess
import os


def init_theli_paths():
    # paths to theli, the GUI scripts and the configuration
    DIRS = {}
    DIRS["HOME"] = os.path.expanduser("~")
    DIRS["PIPEHOME"] = os.path.join(DIRS["HOME"], ".theli")
    DIRS["TEMPDIR"] = os.path.join(DIRS["PIPEHOME"], "tmp")
    DIRS["PY2THELI"] = os.path.join(DIRS["PIPEHOME"], "py2theli")
    # get remaining paths from the initialization script
    sh_vars = ("PIPESOFT", "CONF", "SCRIPTS")  # variables to read from file
    with open(os.path.join(DIRS["PIPEHOME"], "scripts", "progs.ini")) as ini:
        for line in ini:
            # check, if any of the variables is defined in the current line
            for varname in sh_vars:
                if line.startswith(varname):  # fund correct line
                    path = line.split("=")[1]
                    path = path.split(";")[0]  # remove follow-up commands (;)
                    DIRS[varname] = path.strip()
                    break
    # substitute shell variables in paths
    for key in DIRS:
        if "$" in DIRS[key]:
            lead, var = DIRS[key].split("{")
            var, tail = var.split("}")  # var is the variable name
            tail = tail.strip("/")
            DIRS[key] = os.path.join(DIRS[var], tail)  # path: 'variable/tail'
        DIRS[key] = os.path.normpath(DIRS[key])
    # paths to lock-file and wrapper script -> shell for the GUI-scripts
    WRAPPER = os.path.join(DIRS["PY2THELI"], "env_wrapper")
    SYSLOCK = os.path.join(DIRS["PIPEHOME"], "theli.lock")
    LOGFILE = os.path.join(DIRS["PY2THELI"], "theli.log")
    return DIRS, WRAPPER, SYSLOCK, LOGFILE


def init_theli_errors():
    # read the entries in the Theli GUI source file to search for lines in
    # the log file that indicate errors and are not listed as exception
    ERR_KEYS = ["*Error*"]  # additional data
    ERR_EXCEPT = []
    path = os.path.join(DIRS["PIPESOFT"], "gui", "theliform.ui.h")
    with open(path) as cc:
        for line in cc.readlines():
            line = line.strip()
            if line.startswith("errorlist"):
                ERR_KEYS.append(line.split('"')[1])
            if line.startswith("falseerrorlist"):
                ERR_EXCEPT.append(line.split('"')[1])
    return ERR_KEYS, ERR_EXCEPT


def error_in_log(line):
    # check the latest log file
    got_error = any([err in line for err in ERR_KEYS])
    is_false_detection = any([err in line for err in ERR_EXCEPT])
    return True if got_error and not is_false_detection else False


DIRS, WRAPPER, SYSLOCK, LOGFILE = init_theli_paths()
ERR_KEYS, ERR_EXCEPT = init_theli_errors()


initscript = "/home/janluca/.theli/scripts/progs.ini"
scriptdir = "/home/janluca/THELI/theli/gui/scripts"
maindir, sciencedir = os.path.split(
    "/home/janluca/THELI_TRAINING/ACAM/BIAS")


def checked_call(script, arglist, env, parallel=False):
    scriptdir = "/home/janluca/THELI/theli/gui/scripts"
    # assamble command
    if parallel:
        cmdstr = os.path.join(".", "parallel_manager.sh") + " " + script
    else:
        cmdstr = os.path.join(".", script)
    cmdstr = cmdstr + " " + " ".join(arglist)
    # execute command and get log
    stdout = ""
    call = subprocess.Popen(
        cmdstr,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        shell=True, cwd=scriptdir, env=env)
    stdout = call.communicate()[0].decode("utf-8").splitlines()
    # scan log for errors
    return_code = None
    for i, line in enumerate(stdout, 1):
        got_error = any([err in line for err in ERR_KEYS])
        is_false_detection = any([err in line for err in ERR_EXCEPT])
        if got_error and not is_false_detection or i == 100:
            return_code = (line, i)
            break
    # write out log
    with open(LOGFILE, 'w') as log:
        for line in stdout:
            log.write(line + '\n')
    if return_code is not None:
        subprocess.Popen(["gedit", LOGFILE, "+%d" % return_code[1]])
    return return_code


theli_env = os.environ.copy()
theli_env['INSTRUMENT'] = "ACAM@WHT"
return_code = checked_call(
    "process_bias_para.sh", (maindir, sciencedir), theli_env, parallel=True)
print(return_code)
