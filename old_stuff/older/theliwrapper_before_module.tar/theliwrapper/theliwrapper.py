import sys
import os
import subprocess
import shutil
import glob
import re
import time
import itertools
from copy import deepcopy
from collections import namedtuple
try:
    import pyfits
except ImportError:
    from astropy.io import fits as pyfits
from inspect import stack


def init_theli_paths():
    # paths to theli, the GUI scripts and the configuration
    DIRS = {}
    DIRS["HOME"] = os.path.expanduser("~")
    DIRS["PIPEHOME"] = os.path.join(DIRS["HOME"], ".theli")
    DIRS["TEMPDIR"] = os.path.join(DIRS["PIPEHOME"], "tmp")
    DIRS["PY2THELI"] = os.path.join(DIRS["PIPEHOME"], "py2theli")
    # get remaining paths from the initialization script
    sh_vars = ("PIPESOFT", "CONF", "SCRIPTS")  # variables to read from file
    with open(os.path.join(DIRS["PIPEHOME"], "scripts", "progs.ini")) as ini:
        for line in ini:
            # check, if any of the variables is defined in the current line
            for varname in sh_vars:
                if line.startswith(varname):  # fund correct line
                    path = line.split("=")[1]
                    path = path.split(";")[0]  # remove follow-up commands (;)
                    DIRS[varname] = path.strip()
                    break
    # substitute shell variables in paths
    for key in DIRS:
        if "$" in DIRS[key]:
            lead, var = DIRS[key].split("{")
            var, tail = var.split("}")  # var is the variable name
            tail = tail.strip("/")
            DIRS[key] = os.path.join(DIRS[var], tail)  # path: 'variable/tail'
        DIRS[key] = os.path.normpath(DIRS[key])
    # paths to lock-file and wrapper script -> shell for the GUI-scripts
    SYSLOCK = os.path.join(DIRS["PIPEHOME"], "theli.lock")
    LOGFILE = os.path.join(DIRS["PY2THELI"], "theli.log")
    return DIRS, SYSLOCK, LOGFILE


def init_theli_errors():
    # read the entries in the Theli GUI source file to search for lines in
    # the log file that indicate errors and are not listed as exception
    ERR_KEYS = ["*Error*"]  # additional data
    ERR_EXCEPT = []
    path = os.path.join(DIRS["PIPESOFT"], "gui", "theliform.ui.h")
    with open(path) as cc:
        for line in cc.readlines():
            line = line.strip()
            if line.startswith("errorlist"):
                ERR_KEYS.append(line.split('"')[1])
            if line.startswith("falseerrorlist"):
                ERR_EXCEPT.append(line.split('"')[1])
    return ERR_KEYS, ERR_EXCEPT


def init_theli_tags():
    # known FITS-extensions and Theli filename tags
    THELI_TAGS = {"OFC": ("OFC")}
    THELI_FLAGS = ("B", "H", "C", "D", "P", ".sub")
    for n in range(6):
        flags = THELI_FLAGS[:n]
        tags = [""]
        tags.extend(flags)
        for i in range(2, 7):
            tags.extend(list(itertools.combinations(flags, i)))
        tags = ["OFC" + "".join(tup) + THELI_FLAGS[n] for tup in tags]
        THELI_TAGS[THELI_FLAGS[n]] = tuple(tags)
    FITS_EXTENSIONS = (".fits", ".FITS", ".fit", ".FIT", ".fts", ".FTS")
    MASTER_PATTERN = ("BIAS_", "FLAT_", "DARK_")
    return THELI_TAGS, THELI_FLAGS, FITS_EXTENSIONS, MASTER_PATTERN


def init_theli_instruments():
    # collect instrument data
    # every instrument should have a splitting script
    path = os.path.join(DIRS["SCRIPTS"], "process_split_*")
    splitting_scripts = glob.glob(path)
    available_instruments = []
    for fpath in splitting_scripts:
        # remove path, "process_split_" and extension -> instrument name
        instrument = os.path.basename(fpath).split("_", 2)[-1]
        instrument = os.path.splitext(instrument)[0]
        # remove other scripts that made it into the list
        if instrument[0].isupper():
            available_instruments.append(instrument)
    # check the instrument definition files
    chipprops = namedtuple('chipprops', ['SIZEX', 'SIZEY', 'NCHIPS', 'TYPE'])
    INSTRUMENTS = {}
    for instrument in available_instruments:
        if_comm = os.path.join(DIRS["SCRIPTS"], "instruments_commercial",
                               "%s.ini" % instrument)
        if_prof = os.path.join(DIRS["SCRIPTS"], "instruments_professional",
                               "%s.ini" % instrument)
        if os.path.exists(if_comm):
            inifile = if_comm
        elif os.path.exists(if_prof):
            inifile = if_prof
        else:
            # data possibly incomplete -> remove instrument from final list
            continue
        with open(inifile) as ini:
            content = ini.readlines()
        data = {}
        for line in content:
            if "SIZEX=" in line:
                n = line.strip().split("=")
                if len(n) == 3:
                    data["SIZEX"] = int(n[2].strip("()[]"))
                else:
                    data["SIZEX"] = int(n[2].split()[0])
            if "SIZEY=" in line:
                n = line.strip().split("=")
                if len(n) == 3:
                    data["SIZEY"] = int(n[2].strip("()[]"))
                else:
                    data["SIZEY"] = int(n[2].split()[0])
            if "NCHIPS=" in line:
                n = line.strip().split("=")
                data["NCHIPS"] = int(n[1])
            if "TYPE=" in line:
                data["TYPE"] = line.strip().split("=")[1]
        if len(data) == 4:
            INSTRUMENTS[instrument] = chipprops(data["SIZEX"], data["SIZEY"],
                                                data["NCHIPS"], data["TYPE"])
    return INSTRUMENTS


# test terminal capabilities
try:
    # isatty is not always implemented, #6223.
    SUPPORTS_COLOR = False if not (
        sys.platform != 'Pocket PC' and
        (sys.platform != 'win32' or 'ANSICON' in os.environ)) or \
        not hasattr(sys.stdout, 'isatty') and \
        sys.stdout.isatty() else True
except Exception:
    SUPPORTS_COLOR = False


THELI_TAGS, THELI_FLAGS, FITS_EXTENSIONS, MASTER_PATTERN = init_theli_tags()
DIRS, SYSLOCK, LOGFILE = init_theli_paths()
ERR_KEYS, ERR_EXCEPT = init_theli_errors()
INSTRUMENTS = init_theli_instruments()


# ########################################################################### #


if SUPPORTS_COLOR:
    def ascii_styled(string, stylestr):
        """Format the input 'string' using ASCII-escape sequences. The 3-byte
        'stylestr' determines: textstyle, foreground, background-color."""
        # default, bold, greyed, italic, underlined
        attributes = {"-": "0", "b": "1", "t": "2", "i": "3", "u": "4"}
        # black, red, green, yellow, blue, magenta, cyan, white, default
        foreground = {"k": ";30", "r": ";31", "g": ";32", "y": ";33",
                      "b": ";34", "m": ";35", "c": ";36", "w": ";37", "-": ""}
        # black, red, green, yellow, blue, magenta, cyan, white, default
        background = {"k": ";40", "r": ";41", "g": ";42", "y": ";43",
                      "b": ";44", "m": ";45", "c": ";46", "w": ";47", "-": ""}
        head = "\033[%s%s%sm" % (attributes[stylestr[0]],
                                 foreground[stylestr[1]],
                                 background[stylestr[2]])
        tail = "\033[0;0;0m"
        return head + string + tail
else:
    def ascii_styled(string, stylestr):
        return string


def natural_sort(tosort):
    def alphanum_key(key):
        return [int(c) if c.isdigit() else c.lower()
                for c in re.split('([0-9]+)', key)]
    return sorted(tosort, key=alphanum_key)


def sexagesimal_to_degree(sexagesimal_posangle):
    # tested
    ra, dec = sexagesimal_posangle
    ra = ra.replace(":", " ").split()
    h, m, s = [float(i) for i in ra]
    ra_deg = divmod((h + m / 60 + s / 3600) / 24 * 360, 360)[1]
    dec = dec.replace(":", " ").split()
    d, m, s = [float(i) for i in dec]
    dec_deg = d + m / 60 + s / 3600, 360
    return (ra_deg, dec_deg)


def degree_to_sexagesimal(degree_posangle):
    # tested
    ra, dec = degree_posangle
    h, m = divmod(ra, 15)
    h = divmod(h, 24)[1]
    m, s = divmod(m * 60, 15)
    s = s * 60 / 15
    ra_sex = "%02.0f:%02.0f:%05.2f" % (h, m, s)
    d, m = divmod(dec, 1)
    m, s = divmod(m * 60, 1)
    s = s * 60
    dec_sex = "%+3.0f:%02.0f:%04.1f" % (d, m, s)
    return (ra_sex, dec_sex)


def checked_call(script, arglist=None, parallel=False, **kwargs):
    # parse kwargs
    verbosity = kwargs["verb"] if "verb" in kwargs else 1
    env = kwargs["env"] if "env" in kwargs else os.environ.copy()
    # check requested script
    scriptdir = DIRS["SCRIPTS"]
    if not os.path.exists(os.path.join(scriptdir, script)):
        raise FileNotFoundError("script does not exist:", script)
    # assamble command
    if parallel:
        cmdstr = [os.path.join(".", "parallel_manager.sh"), script]
    else:
        cmdstr = [os.path.join(".", script)]
    if arglist is not None:
        cmdstr.extend(arglist)
    # execute command and get log
    call = subprocess.Popen(
        cmdstr, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=False,
        cwd=scriptdir, env=env)
    if verbosity > 1:
        sys.stdout.write("\n")
        # read bytewise from pipe and buffer till newline, then flush to stdout
        stdout = []
        line = b""
        while call.poll() is None:
            out = call.stdout.read(1)
            line += out
            if out == b'\n':
                strline = line.decode("utf-8")
                sys.stdout.write(strline)
                sys.stdout.flush()
                stdout.append(strline.rstrip())
                line = b""
        # capture unhandled buffer
        if out != b'\n':
            line += b'\n'
            strline = line.decode("utf-8")
            sys.stdout.write(strline)
            sys.stdout.flush()
            stdout.append(strline.rstrip())
    else:
        stdout = call.communicate()[0].decode("utf-8").splitlines()
        stdout.append("")
    # scan log for errors
    return_code = (0, "")
    for i, line in enumerate(stdout, 1):
        got_error = any([err in line for err in ERR_KEYS])
        is_false_detection = any([err in line for err in ERR_EXCEPT])
        if got_error and not is_false_detection:
            return_code = (i, line)
            break
    # write out log
    logfile = os.path.join(DIRS["PY2THELI"], "%s.log" % stack()[1][3])
    with open(logfile, 'w') as log:
        for line in stdout:
            log.write(line + '\n')
    if os.path.exists(LOGFILE):
        os.remove(LOGFILE)
    os.link(logfile, LOGFILE)
    return return_code


def get_npara_max(instrument, ncpu):
    try:
        chipprop = INSTRUMENTS[instrument]
        imsize = chipprop.SIZEX * chipprop.SIZEY * 4
        RAM = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')
        return int(0.4 * RAM / imsize / ncpu)
    except KeyError:
        raise ValueError("instrument '%s' is not available" % instrument)


def list_filters(mainfolder, folder, instrument):
    # tested
    if instrument not in INSTRUMENTS:
        raise ValueError("instrument '%s' is not available" % instrument)
    folder = os.path.join(mainfolder, folder)
    filters = set()
    for file in os.listdir(folder):
        path = os.path.join(folder, file)
        if os.path.isfile(path) and path.endswith(FITS_EXTENSIONS):
            # ACAM@WHT
            if instrument == "ACAM@WHT":
                try:
                    with pyfits.open(path) as fits:
                        header = fits[0].header
                        allfilters = header["ACAMFILT"]
                    filter1, filter2 = allfilters.split("+")
                    if filter1 == "CLEAR":
                        new_filter = "+" + filter2
                    else:
                        new_filter = "+" + filter1
                except KeyError:
                    new_filter = header["FILTER"]
            # GMOS-S-HAM@GEMINI
            elif instrument in ("GMOS-S-HAM@GEMINI", "GMOS-S-HAM_1x1@GEMINI"):
                try:
                    with pyfits.open(path) as fits:
                        header = fits[0].header
                        filter1 = header["FILTER1"]
                        filter2 = header["FILTER2"]
                    if "open" in filter1:
                        new_filter = filter2
                    else:
                        new_filter = filter1
                except KeyError:
                    new_filter = header["FILTER"]
            # instrument not implemented
            else:
                raise NotImplementedError(
                    "instrument '%s' has no " % instrument +
                    "implementation of filter keyword")
            filters.add(new_filter)
    # check result
    if len(filters) == 0:
        raise ValueError("Found no FITS-files with valid filter keywords")
    return sorted(filters)


def extract_tag(filename):
    # tested
    # original -> None, splitted -> '', else -> tag without chip number
    fname, ext = os.path.splitext(os.path.split(filename)[1])
    split = fname.rsplit("_", 1)
    if len(split) == 1:
        return 'none'  # original unsplitted file
    if all(char.isdigit() for char in split[1]):
        try:
            with pyfits.open(filename) as fits:
                if "mefsplit" in fits[0].header['HISTORY']:
                    return ''  # splitted image
        except Exception as e:
            raise e
            return 'none'  # original unsplitted file
    # have tag with chip number and flags -> return flags only
    return ''.join([i for i in split[1] if not i.isdigit()])


"""
def check_files_by_tag(self, folder, tag="*", ignore_sub=False):
    # tested (ACAM)
    folder = os.path.join(self.maindir, folder)
    content = os.listdir(folder)
    if "ORIGINALS" in content:
        content = os.listdir(os.path.join(folder, "ORIGINALS"))
    origfiles = [f for f in content if f.endswith(FITS_EXTENSIONS) and
                 not f.startswith(("BIAS_", "DARK_", "FLAT_"))]
    return len(origfiles) == (len(processed_files) // self.nchips)
"""


def check_weights(self):
    def get_files_with_tag(*args):
        raise NotImplementedError()

    # checked
    # get information about weight images
    weights_dir = os.path.join(self.maindir, "WEIGHTS")
    if not os.path.exists(weights_dir):
        return False
    weight_files = [f for f in os.listdir(weights_dir)
                    if f.endswith(".weight.fits")]
    source_files = [".".join(w.split(".weight.")) for w in weight_files]
    # get files in sciencedir that don't have .sub
    sciencedir_abs = os.path.join(self.maindir, self.sciencedir)
    fitsfiles = get_files_with_tag(
        sciencedir_abs, '*', ignore_sub=True)
    # make sure every image has a weight counter part
    if not all([file in source_files for file in fitsfiles]):
        return False
    # read and compare time stamps created by THELI
    stampformat = "%Y-%m-%dT%H:%M:%S"
    for file in fitsfiles:
        try:
            # read science file
            with pyfits.open(os.path.join(sciencedir_abs, file)) as fits:
                header = fits[0].header
            processing_times = [None]
            for line in header['HISTORY']:
                if "called at" in line:
                    processing_times.append(line.split()[-1])
            fits_time = time.strptime(processing_times[-1], stampformat)
            # read weights file
            weight = ".weight".join(os.path.splitext(file))
            with pyfits.open(os.path.join(weights_dir, weight)) as fits:
                header = fits[0].header
            processing_times = [None]
            for line in header['HISTORY']:
                if "called at" in line:
                    processing_times.append(line.split()[-1])
            weight_time = time.strptime(processing_times[-1], stampformat)
            # compare
            assert(fits_time < weight_time)
        except Exception:
            return False
    return True


def check_global_weight(self):
    raise NotImplementedError()


def check_reference_catalogue(self):
    """checks if downloaded file is present in ./theli/tmp"""
    refcatpath = os.path.join(DIRS["TEMPDIR"], "theli_mystd_anet.cat")
    try:
        with pyfits.open(refcatpath) as fits:
            assert(fits[1].data.shape[0] > 10)
    except Exception:
        return False
    return True if os.path.isfile(refcatpath) else False
    # do check: python connection error in log -> distinguish between no
    # sources returned and connecting error


# ########################################################################### #


class Folder(object):
    def __init__(self, path):
        super(Folder, self).__init__()
        self.abs = os.path.abspath(path)
        self.path = os.path.split(self.abs)[1]

    def __str__(self):
        return self.abs

    def __eq__(self, other):
        return self.abs == other

    def folders(self):
        content = [os.path.join(self.abs, c) for c in os.listdir(self.abs)]
        return [c for c in content if os.path.isdir(c)]

    def fits(self, tag='*', ignore_sub=False):
        files = [os.path.join(self.abs, f) for f in os.listdir(self.abs)
                 if os.path.isfile(os.path.join(self.abs, f)) and
                 f.endswith(FITS_EXTENSIONS) and
                 not f.startswith(MASTER_PATTERN)]
        filtered = []
        for f in files:
            filetag = extract_tag(f)
            print(filetag, tag)
            if ignore_sub and filetag.endswith(".sub"):
                continue
            if tag == '*':
                filtered.append(f)
            if tag.endswith('*') and filetag.startswith(tag[:-1]):
                filtered.append(f)
            if tag.startswith('*') and filetag.endswith(tag[1:]):
                filtered.append(f)
            if tag == filetag:
                filtered.append(f)
        return filtered

    def tags(self, ignore_sub=False):
        files = [os.path.join(self.abs, f) for f in os.listdir(self.abs)
                 if os.path.isfile(os.path.join(self.abs, f)) and
                 f.endswith(FITS_EXTENSIONS) and
                 not f.startswith(MASTER_PATTERN)]
        tags = set()
        for f in files:
            new_tag = extract_tag(f)
            if not (ignore_sub and new_tag.endswith("sub")):
                tags.add(new_tag)
        return tags

    def contains(self, entry):
        return entry in os.listdir(self.abs)

    def contains_tag(self, tag):
        return tag in self.tags()

    def contains_master(self):
        fits = [f for f in os.listdir(self.abs)
                if os.path.isfile(os.path.join(self.abs, f)) and
                f.endswith(FITS_EXTENSIONS)]
        return any([f.startswith(MASTER_PATTERN) for f in fits])

    def contains_catfiles(self):
        cat_files = []
        try:
            content = os.listdir(os.path.join(self.abs, "ds9cat"))
            cat_files.extend([f for f in content if f.endswith(".reg")])
        except FileNotFoundError:
            pass
        try:
            content = os.listdir(os.path.join(self.abs, "skycat"))
            cat_files.extend([f for f in content if f.endswith(".skycat")])
        except FileNotFoundError:
            pass
        return len(cat_files) > 2

    def contains_astrometry(self):
        raise NotImplementedError()

    def delete(self, target):
        if os.path.exists(os.path.join(self.abs, target)):
            target = os.path.join(self.abs, target)
            if os.path.isdir(target):
                shutil.rmtree(target)
            elif os.path.isfile(target):
                os.remove(target)

    def delete_tag(self, tag, ignore_sub=False):
        for file in self.fits(tag, ignore_sub):
            try:
                os.remove(os.path.join(self.abs, file))
            except OSError:
                continue

    def delete_master(self):
        master = [os.path.join(self.abs, f) for f in os.listdir(self.abs)
                  if os.path.isfile(os.path.join(self.abs, f)) and
                  f.endswith(FITS_EXTENSIONS) and
                  f.startswith(MASTER_PATTERN)]
        for m in master:
            os.remove(m)

    def restore(self):
        content = os.listdir(self.abs)
        if "ORIGINALS" in content:
            for c in content:
                if c != "ORIGINALS":
                    self.delete(c)
            self.lift_content("ORIGINALS")

    def lift_content(self, subfolder):
        if self.contains(subfolder):
            subfolder = os.path.join(self.abs, subfolder)
            for entry in os.listdir(subfolder):
                shutil.move(
                    os.path.join(subfolder, entry),
                    os.path.join(self.abs, entry))
            shutil.rmtree(subfolder)


# ########################################################################### #


class Parameters(object):
    # keep parameter files for quicker modifications
    param_sets = {"param_set1.ini": [],
                  "param_set2.ini": [],
                  "param_set3.ini": []}
    param_presets = {}
    param_presets["ACAM@WHT"] = {
        'V_BACK_DETECTTHRESH': 1,
        'V_BACK_DETECTMINAREA': 5,
        'V_BACK_MASKEXPAND': 2,
        'V_AP_DETECTTHRESH': 1.5,
        'V_AP_DETECTMINAREA': 5,
        'V_SCAMP_MAXPOSANGLE': 180,
        'V_SKYSUBDETECTTHRESH': 1,
        'V_SKYSUBDETECTMINAREA': 5,
        'V_SKYSUBBACKSIZE': 50,
        'V_AP_MAGLIM': 23}
    param_presets["GMOS-S-HAM@GEMINI"] = {
        'V_BACK_DETECTTHRESH': 1,
        'V_BACK_DETECTMINAREA': 5,
        'V_BACK_MASKEXPAND': 3,
        'V_AP_DETECTTHRESH': 3,
        'V_AP_DETECTMINAREA': 5,
        'V_SCAMP_MAXPOSANGLE': 1,
        'V_SCAMP_MAXOFFSET': 1,
        'V_SCAMP_POLYORDER': 1,
        'V_SCAMP_CROSSIDRADIUS': 2.0,
        'V_SCAMP_ASTREFWEIGHT': 5.0,
        'V_SKYSUBDETECTTHRESH': 1,
        'V_SKYSUBDETECTMINAREA': 5,
        'V_SKYSUBBACKSIZE': 256,
        'V_SKYSUBMASKEXPAND': 3,
        'V_AP_MAGLIM': 23}
    param_presets["GMOS-S-HAM_1x1@GEMINI"] = \
        deepcopy(param_presets["GMOS-S-HAM@GEMINI"])

    def __init__(self):
        super(Parameters, self).__init__()
        """restore default parameters on initialization"""
        self.reset()

    def _modify_parameter_file(self, file_line_list, replace_dict):
        """Modify Theli-parameters of the param_set.ini that are kept in memory
        (file_line_list). Changes are parsed as
        replace_dict[PARAMETER] = VALUE."""
        for i in range(len(file_line_list)):
            for key in replace_dict:
                if file_line_list[i].startswith(key + "="):
                    # if line begins with parameter name (key), replace line
                    val = replace_dict[key]
                    val = str(val) if type(val) != str else val
                    file_line_list[i] = ("%s=%s\n") % (key, val)
                    # remove the parameter from the input dictionary
                    replace_dict.pop(key)
                    break
        # return replace_dict to check, if all parameters were matched
        return file_line_list, replace_dict

    def reset(self):
        """Restore default Theli-parameter files from backup"""
        # read backup of system specific values -> pack as dictionary
        sysdefault = {}
        with open(os.path.join(DIRS["PY2THELI"], "sys.default")) as d:
            for line in d.readlines():
                if "=" in line:
                    key, val = line.split("=", 1)  # split: param-name, value
                    sysdefault[key] = val.strip()
        # read defaults and write new parameter files
        for n in (1, 2, 3):
            fname = "param_set%d.ini" % n
            with open(os.path.join(DIRS["PY2THELI"], fname + ".default")) as f:
                # first file contains system dependent lines, treat separately
                if n == 1:
                    # insert system defaults
                    self.param_sets[fname], remainder = \
                        self._modify_parameter_file(f.readlines(), sysdefault)
                # for file 2 and 3 just replace with backup file content
                else:
                    self.param_sets[fname] = f.readlines()
            with open(os.path.join(DIRS["PIPEHOME"], fname), 'w') as f:
                for line in self.param_sets[fname]:
                    f.write(line)

    def get(self, key):
        for file in self.param_sets:
            for line in self.param_sets[file]:
                if line.startswith(key):
                    return line.split("=", 1)[1].strip()
        raise ValueError("found no parameter matching keyword '%s'" % key)

    def set(self, replace):
        """Wrapper for 'modify_lines_from_dict'. Write changes to theli-
        parameter file. Check, if any unmatched parameter is left"""
        if replace == {}:
            return
        for fname, fcontent in self.param_sets.items():
            # apply changes
            fcontent, replace = self._modify_parameter_file(fcontent, replace)
            with open(os.path.join(DIRS["PIPEHOME"], fname), 'w') as f:
                for line in fcontent:
                    f.write(line)
        # issue warning, if any parameter (key) is left
        if replace != {}:
            print(ascii_styled(
                "WARNING: could not match all parameters:", "by-"))
            for key in replace:
                print("    " + key)

    def preset(self, instrument):
        """Set instrument specific default parameters"""
        self.reset()
        if instrument not in INSTRUMENTS:
            raise ValueError("instrument '%s' is not available" % instrument)
        try:
            self.set(deepcopy(self.param_presets[instrument]))
        except KeyError:
            pass


# ########################################################################### #


class Scripts(object):

    @staticmethod
    def process_split(instrument, maindir, imdir, **kwargs):
        return checked_call(
            "process_split_%s.sh" % instrument,
            [maindir, imdir],
            parallel=False, **kwargs)

    @staticmethod
    def check_files_para(maindir, imdir, tag, minmode, maxmode, **kwargs):
        return checked_call(
            "check_files_para.sh",
            [maindir, imdir, tag, str(minmode), str(maxmode)],
            parallel=True, **kwargs)

    @staticmethod
    def process_bias_para(maindir, biasdir, **kwargs):
        return checked_call(
            "process_bias_para.sh",
            [maindir, biasdir],
            parallel=True, **kwargs)

    @staticmethod
    def process_dark_para(maindir, darkdir, **kwargs):
        return checked_call(
            "process_dark_para.sh",
            [maindir, darkdir],
            parallel=True, **kwargs)

    @staticmethod
    def process_flat_para(maindir, biasdir, flatdir, **kwargs):
        return checked_call(
            "process_flat_para.sh",
            [maindir, biasdir, flatdir],
            parallel=True, **kwargs)

    @staticmethod
    def subtract_flat_flatoff_para(maindir, flatdir, flatoffdir, **kwargs):
        return checked_call(
            "subtract_flat_flatoff_para.sh",
            [maindir, flatdir, flatoffdir],
            parallel=True, **kwargs)

    @staticmethod
    def create_flat_ratio(maindir, flatdir, **kwargs):
        return checked_call(
            "create_flat_ratio.sh",
            [maindir, flatdir],
            parallel=False, **kwargs)

    @staticmethod
    def create_norm_para(maindir, flatdir, **kwargs):
        return checked_call(
            "create_norm_para.sh",
            [maindir, flatdir],
            parallel=True, **kwargs)

    @staticmethod
    def process_science_para(
            maindir, biasdarkdir, flatdir, sciencedir, **kwargs):
        return checked_call(
            "process_science_para.sh",
            [maindir, biasdarkdir, flatdir, sciencedir],
            parallel=True, **kwargs)

    @staticmethod
    def id_bright_objects(maindir, sciencedir, tag="OFC", **kwargs):
        return checked_call(
            "id_bright_objects.sh",
            [maindir, sciencedir, tag],
            parallel=False, **kwargs)

    @staticmethod
    def process_background_para(
            maindir, sciencedir, skydir="noskydir", **kwargs):
        return checked_call(
            "process_background_para.sh",
            [maindir, sciencedir, skydir],
            parallel=True, **kwargs)

    @staticmethod
    def create_global_weights_para(maindir, flatnormdir, sciencedir, **kwargs):
        return checked_call(
            "create_global_weights_para.sh",
            [maindir, flatnormdir, sciencedir],
            parallel=True, **kwargs)

    @staticmethod
    def transform_ds9_reg(maindir, sciencedir, **kwargs):
        # need to rerun global create_global_weights_para before
        return checked_call(
            "transform_ds9_reg.sh",
            [maindir, sciencedir],
            parallel=False, **kwargs)

    @staticmethod
    def create_weights_para(maindir, sciencedir, tag, **kwargs):
        # need to rerun global create_global_weights_para before
        return checked_call(
            "create_weights_para.sh",
            [maindir, sciencedir, tag],
            parallel=True, **kwargs)

    @staticmethod
    def create_astrorefcat_fromWEB(
            maindir, sciencedir, tag, refcat="SDSS-DR9",
            server="vizier.u-strasbg.fr", **kwargs):
        know_refcats = ("SDSS-DR9", "ISGL", "PPMXL", "USNO-B1", "2MASS",
                        "URATI", "SPM4", "UCAC4", "GSC-2.3", "TYC", "ALLSKY")
        if refcat not in know_refcats:
            raise ValueError(
                "unrecognized reference cataloge identifier:", refcat)
        server = "vizier.u-strasbg.fr" if refcat == "SDSS-DR9" else server
        return checked_call(
            "create_astrorefcat_fromWEB.sh",
            [maindir, sciencedir, tag, "%s %s" % (refcat, server)],
            parallel=False, **kwargs)

    @staticmethod
    def create_astromcats_para(maindir, sciencedir, tag, **kwargs):
        return checked_call(
            "create_astromcats_para.sh",
            [maindir, sciencedir, tag],
            parallel=True, **kwargs)

    @staticmethod
    def create_scampcats(maindir, sciencedir, tag, **kwargs):
        # needed for multicolorchips
        return checked_call(
            "create_scampcats.sh",
            [maindir, sciencedir, tag],
            parallel=False, **kwargs)

    @staticmethod
    def create_scamp(
            maindir, sciencedir, tag, photometry_mode=False, **kwargs):
        scampmode = "photom" if photometry_mode else ""
        return checked_call(
            "create_scamp.sh",
            [maindir, sciencedir, tag, scampmode],
            parallel=False, **kwargs)

    @staticmethod
    def create_stats_table(
            maindir, sciencedir, tag, headerdir="headers", **kwargs):
        return checked_call(
            "create_stats_table.sh",
            [maindir, sciencedir, tag, headerdir],
            parallel=False, **kwargs)

    @staticmethod
    def create_absphotom_coadd(maindir, sciencedir, **kwargs):
        return checked_call(
            "create_absphotom_coadd.sh",
            [maindir, sciencedir],
            parallel=False, **kwargs)

    @staticmethod
    def create_skysubconst_clean(maindir, sciencedir, **kwargs):
        return checked_call(
            "create_skysubconst_clean.sh",
            [maindir, sciencedir],
            parallel=False, **kwargs)

    @staticmethod
    def create_skysubconst_para(maindir, sciencedir, tag, **kwargs):
        return checked_call(
            "create_skysubconst_para.sh",
            [maindir, sciencedir, tag],
            parallel=True, **kwargs)

    @staticmethod
    def create_skysub_para(maindir, sciencedir, tag, **kwargs):
        # $4 and $5 in the script are dubious
        return checked_call(
            "create_skysub_para.sh",
            [maindir, sciencedir, tag],
            parallel=True, **kwargs)

    @staticmethod
    def prepare_coadd_swarp(maindir, sciencedir, tag, **kwargs):
        return checked_call(
            "prepare_coadd_swarp.sh",
            [maindir, sciencedir, tag],
            parallel=False, **kwargs)

    @staticmethod
    def resample_coadd_swarp_para(maindir, sciencedir, tag, **kwargs):
        return checked_call(
            "resample_coadd_swarp_para.sh",
            [maindir, sciencedir, tag],
            parallel=True, **kwargs)

    @staticmethod
    def update_coadd_header(maindir, sciencedir, tag, **kwargs):
        # theli GUI places here for tag OFCB, even though OFCB.sub is expected
        return checked_call(
            "update_coadd_header.sh"
            [maindir, sciencedir, tag],
            parallel=False, **kwargs)


# ########################################################################### #


class Reduction(object):

    def __init__(self, instrument, maindir, sciencedir,
                 biasdir=None, darkdir=None, flatdir=None, flatoffdir=None,
                 skydir=None, stddir=None, title="auto", ncpus="max",
                 verbosity="normal"):
        super(Reduction, self).__init__()
        # set title
        if title == "auto":
            self.title = self.sciencedir
        else:
            self.title = title
        # set the main folder
        self.maindir = os.path.abspath(maindir)
        if not os.path.isdir(maindir):
            self.display_error("main-folder invalid:", self.maindir)
        # set the data folders (subfolders of main folder)
        maindir_subfs = [d for d in os.listdir(self.maindir)
                         if os.path.isdir(os.path.join(self.maindir, d))]
        folders = {
            'sciencedir': 'science folder', 'biasdir': 'bias folder',
            'darkdir': 'dark folder', 'flatdir': 'flat folder',
            'flatoffdir': 'flat (off) folder', 'skydir': 'sky folder',
            'stddir': 'standard folder'}
        for folder, name in folders.items():
            input_folder = locals()[folder]
            if input_folder not in maindir_subfs and input_folder is not None:
                self.display_error(
                    "%s is not subfolder of main folder" % name)
            else:
                if input_folder is None:
                    setattr(self, folder, None)
                else:
                    setattr(self, folder, Folder(
                        os.path.join(self.maindir, input_folder)))
        # set the environment and the instrument
        self.theli_env = os.environ.copy()
        if instrument in INSTRUMENTS.keys():
            self.instrument = instrument
            self.theli_env['INSTRUMENT'] = instrument
            self.nchips = INSTRUMENTS[self.instrument].NCHIPS
        else:
            print(self)
            self.display_error("instrument '%s' not recognized" % instrument)
        self.term_size = shutil.get_terminal_size()[0]
        # specify number of cores to use and adjust maximum parallel frames
        self.set_cpus(ncpus)
        # get the filters of files present in the science folder
        try:
            self.filters = list_filters(
                self.maindir, self.sciencedir.path, self.instrument)
        except ValueError:
            print(self)
            self.display_error("found no valid FITS files in science folder")
        self.active_filter = self.filters[0]
        # update the parameters file
        self.params = Parameters()
        self.params.preset(instrument)
        main_params = {'PROJECTNAME': title,
                       'NPARA': str(self.usecpus),
                       'NFRAMES': str(
                           get_npara_max(self.instrument, self.usecpus)),
                       'V_COADD_IDENT': self.active_filter,
                       'V_COADD_FILTER': self.active_filter}
        self.params.set(main_params)
        # empty temp folder
        for tempfile in os.listdir(DIRS["TEMPDIR"]):
            try:
                os.remove(os.path.join(DIRS["TEMPDIR"], tempfile))
            except Exception:
                self.display_warning(
                    "could not remove temporary file: " + tempfile)
        # determine verbosity level
        self.verbosity = 1
        if verbosity in ("quiet", "normal", "extended"):
            verb_modes = {"quiet": 0, "normal": 1, "extended": 2}
            self.verbosity = verb_modes[verbosity]
        if self.verbosity > 0:
            self.display_message(self)

    def __str__(self):
        # print most important project parameters
        self.term_size = shutil.get_terminal_size()[0]
        padding = self.term_size - 24 - len(self.title)
        string = "\n" + ascii_styled("#" * 20 + "  %s  " % self.title, "bw-")
        string += ascii_styled("#" * padding, "bw-") + "\n"
        string += "GUI scipts version:   %s\n" % self.params.get("GUIVERSION")
        if hasattr(self, "maindir"):
            string += "Main-folder:          %s\n" % self.maindir
        if hasattr(self, "biasdir"):
            if self.biasdir is not None:
                string += "Bias folder:          %s\n" % self.biasdir.path
        if hasattr(self, "darkdir"):
            if self.darkdir is not None:
                string += "Dark folder:          %s\n" % self.darkdir.path
        if hasattr(self, "flatdir"):
            if self.flatdir is not None:
                string += "Flat folder:          %s\n" % self.flatdir.path
        if hasattr(self, "flatoffdir"):
            if self.flatoffdir is not None:
                string += "Flat (off) folder:    %s\n" % self.flatoffdir.path
        if hasattr(self, "sciencedir"):
            if self.sciencedir is not None:
                string += "Science folder:       %s\n" % self.sciencedir.path
        if hasattr(self, "skydir"):
            if self.skydir is not None:
                string += "Sky folder:           %s\n" % self.skydir.path
        if hasattr(self, "stddir"):
            if self.stddir is not None:
                string += "Standard folder:      %s\n" % self.stddir.path
        if hasattr(self, "instrument"):
            string += "Instrument:           %s\n" % self.instrument
        if hasattr(self, "filters"):
            string += "Filter(s):            %s\n" % " / ".join(self.filters)
        return string

    def change_active_filter(self, newfilter):
        # given name
        if type(newfilter) == str:
            if newfilter not in self.filters:
                self.error("'%s' not found in data" % newfilter)
            keyword = newfilter
        # given index
        else:
            if newfilter >= len(self.filters):
                self.error("index %d out range in filter list" % newfilter)
            keyword = self.filters[newfilter]
        self.params.set({'V_COADD_IDENT': keyword,
                         'V_COADD_FILTER': keyword})
        self.active_filter = keyword

    def update_env(self, **kwargs):
        for key in kwargs:
            self.theli_env[key] = kwargs[key]

    def set_cpus(self, cpus):
        if cpus == "max":
            self.usecpus = os.cpu_count()
        elif type(cpus) is int:
            self.usecpus = max(1, min(os.cpu_count(), cpus))
        else:
            self.usecpus = 1

    def display_header(self, message):
        if self.verbosity > 0:
            print(ascii_styled(message, "b--"))

    def display_success(self, message, prefix="SKIPPED:"):
        if self.verbosity > 0:
            if prefix is not None:
                print(ascii_styled(prefix, "-g-"), message)
            else:
                print(message)

    def display_message(self, message):
        if self.verbosity > 0:
            print(message)

    def display_warning(self, message):
        if self.verbosity > 0:
            print(ascii_styled("WARNING:", "-y-"), message)

    def display_error(self, message):
        print(ascii_styled("ERROR:  ", "br-"), message + "\n")

    def check_return_code(self, code, ignore_error_code=[]):
        if type(ignore_error_code) is str:
            ignore_error_code = [ignore_error_code]
        if code[0] > 0:
            if code[1] not in ignore_error_code:
                self.display_error(
                    "found in line %d of log:\n         %s" %
                    (code[0], LOGFILE))
                if os.isatty(sys.stdout.fileno()):
                    sys.stdout.write("displaying the log ")
                    sys.stdout.flush()
                    time.sleep(1)
                    for i in range(3):
                        sys.stdout.write(".")
                        sys.stdout.flush()
                        time.sleep(1)
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                else:
                    print("displaying the log ...")
                    time.sleep(4)
                view_commands = [
                    ["nano", "+%d" % code[0], LOGFILE],
                    ["gedit", "+%d" % code[0], LOGFILE, "/dev/null", "2>&1"],
                    ["emacs", "+%d" % code[0], LOGFILE, "/dev/null", "2>&1"],
                    ["kate", '-l', str(code[0]), LOGFILE, "/dev/null", "2>&1"]]
                for command in view_commands:
                    try:
                        subprocess.call(command)
                        break
                    except FileNotFoundError:
                        continue
                sys.exit(1)
            else:
                self.warning(
                    "ignored error in line %d of log: %s" % (code[0], LOGFILE))

    # ################## processing steps ##################

    #
    # WHAT IS THIS?
    #
    #
    # if (command.find("check_rawfilenames.sh") != -1)
    # reply.append("Checking filename consistency ...");
    #
    # if (command.find("cleanfiles.sh") != -1)
    # reply.append("Deleting temporary data ...");
    #
    # if (command.find("link_globalweights_para.sh") != -1)
    # reply.append("Creating WEIGHTs ...");
    #
    # if (command.find("transform_images_para.sh") != -1)
    # reply.append("Transforming images and weights ...");
    #
    # if (command.find("correct_crval_para.sh") != -1)
    # reply.append("Adjusting CRVAL1/2 key in header ...");
    #
    # if (command.find("create_astromcats_para.sh") != -1)
    # reply.append("Detecting sources ...");
    #
    # if (command.find("create_astromcats_phot_para.sh") != -1)
    # reply.append("Detecting sources for abs photometry ...");
    #
    # if (command.find("create_photorefcat_fromWEB.sh") != -1)
    # reply.append("Retrieving photometric reference catalog ...");
    #
    # if (command.find("create_photillcorr_corrcat_para.sh") != -1)
    # reply.append("Correcting astrometry in catalogs ...");
    #
    # if (command.find("create_photillcorr_getZP.sh") != -1)
    # reply.append("Estimating direct absolute zeropoints ...");
    #
    # if (command.find("create_stdphotom_prepare.sh") != -1)
    # reply.append("Preparing photometry catalogs ...");
    #
    # if (command.find("create_abs_photo_info.sh") != -1)
    # reply.append("Estimating indirect absolute zeropoints ...");
    #
    # if (command.find("create_zeroorderastrom.sh") != -1)
    # reply.append("Calculating astrometric solution ...");
    #
    # if (command.find("create_xcorrastrom.sh") != -1)
    # reply.append("Calculating astrometric solution ...");
    #
    # if (command.find("create_headerastrom.sh") != -1)
    # reply.append("Calculating astrometric solution ...");
    #
    # if (command.find("create_astrometrynet.sh") != -1)
    # reply.append("Calculating astrometric solution ...");
    #
    # if (command.find("create_astrometrynet_photom.sh") != -1)
    # reply.append("Calculating photometric solution ...");
    #
    # if (command.find("create_scamp_phot.sh") != -1)
    # reply.append("Calculating 1st pass astrometric solution ...");
    #
    # if (command.find("create_smoothedge_para.sh") != -1)
    # reply.append("Coaddition: smoothing overlap ...");
    #
    # if (command.find("resample_filtercosmics.sh") != -1)
    # reply.append("Coaddition: rejecting outliers ...");
    #

    def sort_data_using_FITS_key(self):
        # if (command.find("sort_rawdata.sh") != -1)
        # reply.append("Sorting raw data ...");
        raise NotImplementedError()

    def split_FITS_correct_header(self):
        correct_xtalk = (
            self.params.get("V_PRE_XTALK_NOR_CHECKED") != '0' or
            self.params.get("V_PRE_XTALK_ROW_CHECKED") != '0' or
            self.params.get("V_PRE_XTALK_MULTI_CHECKED") != '0')
        foldervars = ['biasdir', 'darkdir', 'flatdir', 'flatoffdir',
                      'sciencedir', 'skydir', 'stddir']
        IDs = [' (bias)', ' (dark)', ' (flat)', ' (flat off)',
               ' (science)', ' (sky)', ' (standard)']
        for foldervar, ID in zip(foldervars, IDs):
            fallback_message = "Splitting FITS, correcting headers" + ID
            # folder verification
            folder = getattr(self, foldervar)
            if folder is None:
                continue
            filetags = folder.tags(ignore_sub=True)
            found_original_files = folder.contains_tag('none')
            found_split_files = folder.contains_tag('')
            found_split_dir = folder.contains("SPLIT_IMAGES")
            found_masterframe = folder.contains_master()
            # data verification
            if len(filetags) > 1:
                self.display_header(fallback_message)
                self.display_error("found multiple progress stages")
                sys.exit(1)
            if found_masterframe:
                self.display_header(fallback_message)
                self.display_success("master %s found" % ID[2:-1])
                continue
            if found_split_files or found_split_dir:
                self.display_header(fallback_message)
                self.display_success("split images found")
                continue
            if not found_original_files:
                self.display_header(fallback_message)
                self.display_error("no original images found")
                sys.exit(1)
            # run jobs
            # split images
            self.display_header("Splitting FITS, correcting headers" + ID)
            code = Scripts.process_split(
                self.instrument, self.maindir, folder.path,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
            if correct_xtalk:
                # optional: cross talk correction
                self.display_header("Correcting for crosstalk")
                raise NotImplementedError(
                    "Cross talk correction not implented yet")
        self.display_message("")

    def create_links(self):
        # if (command.find("createlinks.sh") != -1)
        # reply.append("Creating links ...");
        raise NotImplementedError()

    def process_biases(self, minmode=None, maxmode=None, redo=False):
        fallback_message = "Processsing BIASes"
        # folder verification
        if self.biasdir is None:
            self.display_header(fallback_message)
            self.display_error("bias folder not specified")
            sys.exit(1)
        filetags = self.biasdir.tags(ignore_sub=True)
        found_split_files = self.biasdir.contains_tag('')
        found_masterbias = self.biasdir.contains_master()
        # data verification
        if len(filetags) > 1:
            self.display_header(fallback_message)
            self.display_error("found multiple progress stages")
            sys.exit(1)
        if not redo and found_masterbias:
            self.display_header(fallback_message)
            self.display_success("master bias found")
            self.display_message("")
            return
        if redo and found_masterbias and not found_split_files:
            self.display_warning("no split images found - skipping redo")
            self.display_message("")
            return
        if not found_split_files:
            self.display_header(fallback_message)
            self.display_error("no split images found")
            sys.exit(1)
        # run jobs
        if redo:
            self.biasdir.delete_master()
        if minmode is not None and maxmode is not None:
            # optional: brightness level check
            self.display_header("Checking brightness levels")
            code = Scripts.check_files_para(
                self.maindir, self.biasdir.path, "empty", minmode, maxmode,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
        # compute master bias
        self.display_header("Processing BIASes")
        code = Scripts.process_bias_para(
            self.maindir, self.biasdir.path,
            env=self.theli_env, verb=self.verbosity)
        self.check_return_code(code)
        self.display_message("")

    def process_darks(self, minmode=None, maxmode=None, redo=False):
        fallback_message = "Processsing DARKs"
        # folder verification
        if self.darkdir is None:
            self.display_header(fallback_message)
            self.display_error("dark folder not specified")
            sys.exit(1)
        filetags = self.darkdir.tags(ignore_sub=True)
        found_split_files = self.darkdir.contains_tag('')
        found_masterdark = self.darkdir.contains_master()
        # data verification
        if len(filetags) > 1:
            self.display_header(fallback_message)
            self.display_error("found multiple progress stages")
            sys.exit(1)
        if not redo and found_masterdark:
            self.display_header(fallback_message)
            self.display_success("master dark found")
            self.display_message("")
            return
        if redo and found_masterdark and not found_split_files:
            self.display_warning("no split images found - skipping redo")
            self.display_message("")
            return
        if not found_split_files:
            self.display_header(fallback_message)
            self.display_error("no split images found")
            sys.exit(1)
        # run jobs
        if redo:
            self.darkdir.delete_master()
        if minmode is not None and maxmode is not None:
            # optional: brightness level check
            self.display_header("Checking brightness levels")
            code = Scripts.check_files_para(
                self.maindir, self.biasdir.path, "empty", minmode, maxmode,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
        # compute master dark
        self.display_header("Processing DARKs")
        code = Scripts.process_dark_para(
            self.maindir, self.darkdir.path,
            env=self.theli_env, verb=self.verbosity)
        self.check_return_code(code)
        self.display_message("")

    def process_flats(self, minmode=None, maxmode=None, redo=False):
        # folder verification
        fallback_message = "Processsing FLATs"
        if self.flatdir is None:
            self.display_header(fallback_message)
            self.display_error("flat folder not specified")
            sys.exit(1)
        apply_bias = self.params.get("V_DO_BIAS") == "Y"
        if apply_bias:
            if self.biasdir is None:
                self.display_header(fallback_message)
                self.error("bias folder not specified")
                sys.exit(1)
            if not self.biasdir.contains_master():
                self.display_header(fallback_message)
                self.error("master bias not found")
                sys.exit(1)
        # queue data folders (optinal: have flatoff-dir)
        folders = [self.flatdir]
        IDs = [""]
        any_master_updated = False
        if self.flatoffdir is not None:
            folders.append(self.flatoffdir)
            IDs.append(" (off)")
        for folder, ID in zip(folders, IDs):
            fallback_message = "Processsing FLATs" + ID
            filetags = folder.tags(ignore_sub=True)
            found_split_files = folder.contains_tag('')
            found_masterflat = folder.contains_master()
            # data verification
            if len(filetags) > 1:
                self.display_header(fallback_message)
                self.display_error("found multiple progress stages")
                sys.exit(1)
            if not redo and found_masterflat:
                self.display_header(fallback_message)
                self.display_success("master flat found")
                continue
            if redo and found_masterflat and not found_split_files:
                self.display_warning("no split images found - skipping redo")
                continue
            if not found_split_files:
                self.display_header(fallback_message)
                self.display_error("no split images found")
                sys.exit(1)
            # run jobs
            if redo:
                folder.delete_master()
            if ID == "" and (minmode is not None and maxmode is not None):
                # optional: brightness level check (flat only)
                self.display_header("Checking brightness levels")
                code = Scripts.check_files_para(
                    self.maindir, self.biasdir.path, "empty", minmode, maxmode,
                    env=self.theli_env, verb=self.verbosity)
                self.check_return_code(code)
            # compute master flats (optional with flatoff)
            self.display_header("Processing FLATs" + ID)
            code = Scripts.process_flat_para(
                self.maindir, self.biasdir.path, folder.path,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
            any_master_updated = True
        # if any master frame has been modified
        if any_master_updated:
            # optional: subtract flatoff from flat
            if self.flatoffdir is not None:
                self.display_header("Subtracting dark flat from bright flat")
                code = Scripts.subtract_flat_flatoff_para(
                    self.maindir, self.flatdir.path, self.flatoffdir.path,
                    self._ckwargs)
                self.check_return_code(code)
            # measure gain ratio
            self.display_header("Measuring gain ratios")
            code = Scripts.create_flat_ratio(
                self.maindir, self.flatdir.path,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
            # normalize flat
            self.display_header("Normalising FLAT")
            code = Scripts.create_norm_para(
                self.maindir, self.flatdir.path,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
        self.display_message("")

    def calibrate_data(self, usedark=False, minmode=None, maxmode=None,
                       redo=False):
        # folder verification
        fallback_message = "Calibrating data"
        if self.sciencedir is None:
            self.display_header(fallback_message)
            self.display_error("science folder not specified")
            sys.exit(1)
        apply_flat = self.params.get("V_DO_FLAT") == "Y"
        if apply_flat:
            if self.flatdir is None:
                self.display_header(fallback_message)
                self.display_error("flat folder not specified")
                sys.exit(1)
            if not self.flatdir.contains_master():
                self.display_header(fallback_message)
                self.display_error("master flat not found")
        biasdarkdir = self.darkdir if usedark else self.biasdir
        ID_biasdark = "dark" if usedark else "bias"
        apply_biasdark = self.params.get("V_DO_BIAS") == "Y"
        if apply_biasdark:
            if biasdarkdir is None:
                self.display_header(fallback_message)
                self.display_error("%s folder not specified" % ID_biasdark)
                sys.exit(1)
            if not biasdarkdir.contains_master():
                self.display_header(fallback_message)
                self.display_error("master %s not found" % ID_biasdark)
                sys.exit(1)
        # queue data folders (optinal: have flatoff-dir)
        folders = [self.sciencedir]
        IDs = [""]
        if self.skydir is not None:
            folders.append(self.skydir)
            IDs.append(" (sky)")
        if self.stddir is not None:
            folders.append(self.stddir)
            IDs.append(" (standard)")
        for folder, ID in zip(folders, IDs):
            fallback_message = "Calibrating data" + ID
            filetags = folder.tags(ignore_sub=True)
            found_split_folder = folder.contains("SPLIT_IMAGES")
            found_split_files = folder.contains_tag('')
            found_OFC_files = folder.contains_tag('OFC')
            # data verification
            if len(filetags) > 1:
                self.display_header(fallback_message)
                self.display_error("found multiple progress stages")
                sys.exit(1)
            if not redo and found_OFC_files:
                self.display_header(fallback_message)
                self.display_success("OFC images found")
                continue
            if redo and found_OFC_files and \
                    not (found_split_files or found_split_folder):
                self.display_warning("no split images found - skipping redo")
                continue
            if not found_split_files:
                self.display_header(fallback_message)
                self.display_error("no split images found")
                sys.exit(1)
            # run jobs
            if redo:
                folder.delete_tag("OF*", ignore_sub=True)
                folder.lift_content("SPLIT_IMAGES")
            if ID == "" and (minmode is not None and maxmode is not None):
                # optional: brightness level check (science only)
                self.display_header("Checking brightness levels" + ID)
                code = Scripts.check_files_para(
                    self.maindir, folder.path, "empty", minmode, maxmode,
                    env=self.theli_env, verb=self.verbosity)
                self.check_return_code(code)
            # calibrate data
            self.display_header("Calibrating data" + ID)
            code = Scripts.process_science_para(
                self.maindir, biasdarkdir.path, self.flatdir.path, folder.path,
                env=self.theli_env, verb=self.verbosity)
            self.check_return_code(code)
        self.display_message("")

    def spread_sequence(self):
        if INSTRUMENTS[self.instrument].TYPE != "NIR":
            self.message("Grouping images")
            self.error(
                "method only avaliable for NIR instruments", critical=False)
        raise NotImplementedError()

    def background_model_correction(self, redo=False):
        raise NotImplementedError()

        def ofc_restore(folder):
            ofcfolder = os.path.join(
                self.maindir, folder, "OFC_IMAGES")
            delete_fits_with_tag(
                os.path.join(self.maindir, folder), "OFCB",
                ignore_sub=True)
            if os.path.exists(ofcfolder):
                move_content_to_parent(ofcfolder)
            try:
                shutil.rmtree(
                    os.path.join(self.maindir, folder, "BACKGROUND"))
            except FileNotFoundError:
                pass
            try:
                shutil.rmtree(
                    os.path.join(self.maindir, folder, "MASK_IMAGES"))
            except FileNotFoundError:
                pass

        check_bright_stars = self.params.get("V_BACK_MAGLIMIT") != ""
        filetypes = list_all_tags(
            os.path.join(self.maindir, self.sciencedir), ignore_sub=True)
        # folder verification
        if self.sciencedir is None:
            self.message("Background modelling")
            self.error("science folder not specified")
        # data verification
        elif len(filetypes) > 1:
            self.message("Background modelling")
            self.error("found multiple processing steps")
        elif not redo and self.check_files_by_tag(self.sciencedir, "OFCB"):
            self.message("Background modelling")
            self.success("OFCB images found")
        elif filetypes != {"OFC"} and not os.path.isdir(
                os.path.join(self.maindir, self.sciencedir, "OFC_IMAGES")):
            self.message("Background modelling")
            self.error("no OFC images found")
        # run jobs
        else:
            if redo:
                ofc_restore(self.sciencedir)
                if self.skydir is not None:
                    ofc_restore(self.skydir)
                if self.stddir is not None:
                    ofc_restore(self.stddir)
            if self.skydir is not None:
                # ./id_bright_objects.sh main sky tag
                # ./PMAN.sh process_background_para.sh main science sky
                # ./PMAN.sh process_background_para.sh main science noskydir
                raise NotImplementedError("SKYDIR correction not implemented")
            if check_bright_stars:
                self.message("Identifying chips with bright stars")
                self.return_code_check(
                    self.id_bright_objects("OFC"))
            self.message("Background modelling")
            self.return_code_check(
                self.process_background_para("noskydir"))
        self.message("")

    def merge_sequence(self):
        if INSTRUMENTS[self.instrument].TYPE != "NIR":
            self.message("Collecting images")
            self.error(
                "method only avaliable for NIR instruments", critical=False)
        raise NotImplementedError()

    def chop_nod_skysub(self):
        if INSTRUMENTS[self.instrument].TYPE != "MIR":
            self.message("Subtracting sky by chop-nod")
            self.error(
                "method only avaliable for MIR instruments", critical=False)
        raise NotImplementedError()

    def collapse_correction(self):
        # NEEDS reset
        # reply.append("Collapse correction ...");
        # if (command.find("create_debloomedimages_para.sh") != -1)
        raise NotImplementedError()

    def debloom_images(self):
        # NEEDS reset
        if INSTRUMENTS[self.instrument].TYPE != "OPT":
            self.message("Deblooming images")
            self.error(
                "method only avaliable for optical instruments",
                critical=False)
        raise NotImplementedError()

    def create_binned_preview(self):
        # this is where we need 'makealbum@....sh' and 'create_tiff.sh'
        # if (command.find("make_album_") != -1)
        # reply.append("Creating fits preview ...");
        # if (command.find("create_tiff.sh") != -1)
        # reply.append("Creating tiff preview ...");
        raise NotImplementedError()

    # ######## CHECK IF NEED TO REDO #######
    def create_global_weights(self):
        raise NotImplementedError()
        master_flatnorm_present = check_master_flat(
            self.maindir, self.flatdir, self.instrument)
        displayed = "Creating global WEIGHTs"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if not master_flatnorm_present:
                notify.error("master flat field not found")
            else:
                Scripts.create_global_weights_para(
                    self.maindir, self.flatdir + "_norm", self.sciencedir)

    def create_weights(self, redo=False):
        raise NotImplementedError()
        all_tags = list(list_all_tags(
            os.path.join(self.maindir, self.sciencedir)))
        current_tag = [t for t in all_tags if ".sub" not in t][0]
        weigts_present = check_weights(self.maindir, self.sciencedir)
        if not weigts_present:
            redo = True
        displayed = "Transforming DS9 masks"
        with pnotify(self.projectname, stack()[0][3], displayed):
            Scripts.transform_ds9_reg(self.maindir, self.sciencedir)
        displayed = "Creating WEIGHTs"
        with pnotify(self.projectname, stack()[0][3], displayed):
            Scripts.create_weights_para(
                self.maindir, self.sciencedir, current_tag)

    def distribute_target_sets(self):
        # if (command.find("distribute_sets.sh") != -1)
        # reply.append("Separating different target fields ...");
        raise NotImplementedError()

    def get_refcat(self, refcat, server, redo=False):
        raise NotImplementedError()
        all_tags = list(list_all_tags(
            os.path.join(self.maindir, self.sciencedir)))
        current_tag = [t for t in all_tags if ".sub" not in t][0]
        displayed = "Retrieving astrometric reference catalog (%s)" % refcat
        refcat_present = os.path.exists(
            os.path.join(DIRS["TEMPDIR"], "theli_mystd_anet.cat"))
        with pnotify(self, stack()[0][3], displayed) as notify:
            if refcat_present and not redo:
                notify.success("found")
            else:
                # NOTE: distinguish between connection fail and
                # no source returned
                retries = 10
                for i in range(retries + 1):
                    try:
                        Scripts.create_astrorefcat_fromWEB(
                            self.maindir, self.sciencedir, current_tag,
                            refcat, server)
                    except ValueError:
                        notify.error("unrecognized reference cataloge")
                    if reference_catalogue_from_web_is_valid():
                        break
                    if retries - i == 0:
                        notify.error("failed to connect")
                        sys.exit(1)
                    notify.warning("retry (%d/%d)" % (i + 1, retries))
                    subprocess.call(["sleep", str(1.5 ** (i + 1) + 1)])

    def absolute_photometry_indirect(self):
        raise NotImplementedError()

    def absolute_photometry_direct(self):
        # NEEDS reset
        raise NotImplementedError()

    def create_source_cat(self, redo=False):
        raise NotImplementedError()
        cat_files_present = check_cat_files(
            self.maindir, self.sciencedir)
        all_tags = list(list_all_tags(
            os.path.join(self.maindir, self.sciencedir)))
        current_tag = [t for t in all_tags if ".sub" not in t][0]
        displayed = "Detecting sources"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if cat_files_present and not redo:
                notify.success("found")
            else:
                Scripts.create_astromcats_para(
                    self.maindir, self.sciencedir, current_tag)
        if self.nchips > 1:
            displayed = "Merging multi-chip object catalogs"
            with pnotify(self.projectname, stack()[0][3], displayed) as notify:
                if cat_files_present and not redo:
                    notify.success("skipped")
                else:
                    Scripts.create_scampcats(
                        self.maindir, self.sciencedir, current_tag)

    def astro_and_photometry(self, redo=False):
        raise NotImplementedError()
        scamp_log_present = os.path.exists(
            self.maindir, self.sciencedir, "plots", "scamp.log")
        all_tags = list(list_all_tags(
            os.path.join(self.maindir, self.sciencedir)))
        current_tag = [t for t in all_tags if ".sub" not in t][0]
        displayed = "Calculating astrometric solution"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if scamp_log_present and not redo:
                notify.success("found")
            else:
                Scripts.create_scamp(
                    self.maindir, self.sciencedir, current_tag)
        displayed = "Collecting image statistics"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if scamp_log_present and not redo:
                notify.success("skipped")
            else:
                Scripts.create_stats_table(
                    self.maindir, self.sciencedir, current_tag, "headers")
        displayed = "Collecting information for coaddition"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if scamp_log_present and not redo:
                notify.success("skipped")
            else:
                Scripts.create_absphotom_coadd(
                    self.maindir, self.sciencedir)

    def sky_subtraction(self, model="smoothed", redo=False):
        raise NotImplementedError()
        all_tags = list(list_all_tags(
            os.path.join(self.maindir, self.sciencedir)))
        input_complete = check_files_by_tag(
            self.maindir, self.sciencedir, self.instrument, "OFC*", True)
        current_tag = [t for t in all_tags if ".sub" not in t][0]
        skysub_present = check_files_by_tag(
            self.maindir, self.sciencedir, "*.sub")
        if model == "const":
            displayed = "Preparing sky subtraction"
            with pnotify(self.projectname, stack()[0][3], displayed) as notify:
                if not input_complete:
                    notify.error("input images not found")
                if skysub_present and not redo:
                    notify.success("skipped")
                else:
                    Scripts.create_skysubconst_clean(
                        self.maindir, self.sciencedir)
            displayed = "Subtracting the sky"
            with pnotify(self.projectname, stack()[0][3], displayed) as notify:
                if not input_complete:
                    notify.error("input images not found")
                if skysub_present and not redo:
                    notify.success("found")
                else:
                    Scripts.create_skysubconst_para(
                        self.maindir, self.sciencedir, current_tag)
        else:
            displayed = "Subtracting the sky"
            with pnotify(self.projectname, stack()[0][3], displayed) as notify:
                if not input_complete:
                    notify.error("input images not found")
                if skysub_present and not redo:
                    notify.success("found")
                else:
                    Scripts.create_skysub_para(
                        self.maindir, self.sciencedir, current_tag)

    # check weights file presence
    def coaddition(self, redo=False):
        raise NotImplementedError()
        # if (command.find("perform_coadd_swarp.sh") != -1)
        # reply.append("Coaddition: coadding images ...");

        all_tags = list(list_all_tags(
            os.path.join(self.maindir, self.sciencedir)))
        weigts_present = check_weights(self.maindir, self.sciencedir)
        coadd_present = check_coadd(
            self.maindir, self.sciencedir, self.science_filter)
        current_tag = [t for t in all_tags if ".sub" not in t][0]  # astounding
        displayed = "Coaddition: initialising"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if not weigts_present:
                notify.error("missing weight images")
            if coadd_present and not redo:
                notify.success("skipped")
            else:
                Scripts.prepare_coadd_swarp(
                    self.maindir, self.sciencedir, current_tag)
        displayed = "Coaddition: resampling images"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if not weigts_present:
                notify.error("missing weight images")
            if coadd_present and not redo:
                notify.success("found")
            else:
                Scripts.resample_coadd_swarp_para(
                    self.maindir, self.sciencedir, current_tag)
        displayed = "Coaddition: updating header"
        with pnotify(self.projectname, stack()[0][3], displayed) as notify:
            if not weigts_present:
                notify.error("missing weight images")
            if coadd_present and not redo:
                notify.success("skipped")
            else:
                Scripts.update_coadd_header(
                    self.maindir, self.sciencedir, current_tag)

    def resolve_links(self):
        # if (command.find("resolvelinks.sh") != -1)
        # reply.append("Resolving link structure ...");
        raise NotImplementedError()


THELI = Reduction("ACAM@WHT", "/home/janluca/THELI_TRAINING/ACAM", "SCIENCE",
                  biasdir="BIAS", flatdir="FLAT", title="testrun",
                  verbosity="normal")
THELI.biasdir.restore()
THELI.flatdir.restore()
THELI.sciencedir.restore()
THELI.split_FITS_correct_header()
THELI.process_biases()
# THELI.process_darks()
THELI.process_flats()
THELI.calibrate_data()
# THELI.background_model_correction()
