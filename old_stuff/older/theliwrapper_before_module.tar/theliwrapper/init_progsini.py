import os
import subprocess


scriptdir = "/home/janluca/THELI/theli/gui/scripts"
progs_ini = os.path.join(scriptdir, "progs.ini")

progs = []
with open(progs_ini) as ini:
    for line in ini:
        line = line.strip()
        if line == '' or line[0] == '#' or "if" in line:
            continue
        print(repr(line.strip()))
        progs.append(line)

envvars = {}
for line in progs:
    if "=" in line and "$" not in line:
        var, value = line.split("=", 1)
        envvars[var] = value
print(envvars)

for line in progs:
    if "=" in line and "$" in line:
        var, value = line.split("=", 1)
        substitute = ""
        rest = ""
        for i, char in enumerate(value):
            if char == "{":
                for j, char in enumerate(value[i + 1:], i + 1):
                    if char == "}":
                        break
                    substitute += char
                rest = value[j + 1:]
                break
        envvars[var] = envvars[substitute] + rest

print(envvars)

exit()

theli_env = os.environ.copy()

p = subprocess.Popen(["echo ${newinst}"], env=theli_env, shell=True)
p.wait()
